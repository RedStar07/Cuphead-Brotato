extends Node

const MOD_ID := "CupheadBrotato-Mashup"
const MOD_DIR := "CupheadBrotato-Mashup"

func _init():
    ModLoaderLog.info("Init", MOD_ID + ": source scaffold loaded")
    var mod_dir = ModLoaderMod.get_unpacked_dir().plus_file(MOD_DIR)
    # Runtime registration is intentionally kept behind the installed ContentLoader API.
    # The exact resource paths and hooks must be resolved against the player's Brotato build.
    if Engine.has_singleton("ContentLoader"):
        ModLoaderLog.info("Init", MOD_ID + ": ContentLoader detected")
    else:
        ModLoaderLog.warn("Init", MOD_ID + ": ContentLoader API not detected; gameplay registration skipped")
