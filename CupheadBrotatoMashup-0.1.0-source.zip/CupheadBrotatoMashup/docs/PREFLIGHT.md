# Preflight 0.1

## Unfilled / unverified cells

All design-sheet cells are filled. Runtime verification remains intentionally open because the host game is not accessible in this session.

## Unresolved cross-sheet references

- `systems.weapon_registration -> ContentLoader` is an external runtime dependency and must be confirmed against the installed Brotato/ContentLoader version.
- `systems.character_select -> CharacterData` must be mapped against the installed Brotato data schema.
- `systems.boss_encounter -> wave hooks / EnemyData` must be mapped against the installed Brotato version.

## Build gate

**BLOCKED for a real in-game build/test** until a Brotato installation is accessible. Do not publish or claim one-click compatibility from this source-only scaffold.
