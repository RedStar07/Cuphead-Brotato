# Game design

## One sentence

Brotato's fast arena-survival loop becomes a Cuphead boss-rush sandbox: pick one of eight very different Cuphead fighters, mix Brotato and Cuphead-style weapons, survive normal waves, and periodically fight a Cuphead boss occupying an elite-sized slice of the wave.

## First minute

- Choose any of the 8 characters.
- Start with a character-appropriate weapon choice.
- Move, shoot, collect XP/materials and fill the signature meter through the character's specialty.
- At the first shop, buy/upgrade one weapon.
- Wave 3 previews the first boss mechanic; wave 4 uses Cagney as the first complete encounter.

## Balance rule

Bosses are not separate Cuphead stages. They are elite replacements/augmentations. Their damage windows, telegraphs and HP budget must preserve Brotato's 20-second-ish wave cadence.

## Multiplayer

Version 0.1 is single-player. No multiplayer capacity or connection recipe is invented.
