# Cuphead × Brotato — first playable source

A single-player Brotato-hosted mashup. The player chooses one of eight Cuphead characters, equips Brotato/Cuphead-style weapons, survives escalating Brotato waves, and faces Cuphead-style boss encounters that can replace or augment elite waves.

## Current state

**Source/design scaffold — not yet tested in Brotato.** The current machine session does not expose a Brotato or Cuphead installation, and Godot is not installed, so no honest claim of in-game execution is made yet.

The design is intentionally data-driven. `sheets/*.json` are the source of truth; every row is intended to map to one content/runtime object.

## First playable slice

1. Character select: all 8 characters unlocked.
2. Brotato wave loop remains the host loop.
3. Character passive is always active.
4. Signature meter fills through each character's specialty and unleashes a character-specific move.
5. Weapon pool contains Brotato-style weapons plus Cuphead-inspired signature weapons.
6. One boss encounter is used as the first boss/elite replacement prototype: Cagney Carnation.
7. Boss encounters are tuned to occupy an elite slot rather than pause the run for a separate boss game.

## Host route

Brotato + Godot Mod Loader + ContentLoader is the intended route. The mod should ship only its own code/data/assets and rely on the player's Brotato installation for game content. ContentLoader is a common route for registering new characters and weapons.

## Not included

No Brotato or Cuphead game files, decompiled game code, proprietary sprites, audio, or fonts are included.
